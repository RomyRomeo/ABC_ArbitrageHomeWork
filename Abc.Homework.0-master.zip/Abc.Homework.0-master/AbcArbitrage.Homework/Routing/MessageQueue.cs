// Copyright (C) Abc Arbitrage Asset Management - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// Proprietary and confidential
// Written by Olivier Coanet <o.coanet@abc-arbitrage.com>, 2020-10-06

using System.Collections.Generic;
using System.Linq.Expressions;

namespace AbcArbitrage.Homework.Routing
{
    public class MessageQueue
    {
        //ADDED
        private class ClientAndMessage
        {
            public ClientId ClientId { get; set; }
            public IMessage Message { get; set; }
            public ClientAndMessage(ClientId clientId, IMessage message)
            {
                this.ClientId = clientId;
                this.Message = message;
            }
        

            public bool Equals(ClientAndMessage? other) => other != null
                                                   && ClientId.Equals(other.ClientId)
                                                   && Message.Equals(other.Message);
        }

        PriorityQueue<ClientAndMessage, MessagePriority> priorityQueue;

        public MessageQueue()
        {
            this.priorityQueue = new PriorityQueue<ClientAndMessage, MessagePriority>();

        }
        public void EnqueueForClient(ClientId clientId, IMessage message, MessagePriority priority = MessagePriority.Normal)
        {
            // TODO => DONE
            priorityQueue.Enqueue(new ClientAndMessage(clientId, message), priority);


        }

        public bool TryDequeueForClient(ClientId clientId, out IMessage? message)
        {
            // TODO => DONE


            message = default;

            if (priorityQueue.Count > 0)
            {
                ClientAndMessage clientAndMessage;
                do
                {
                    clientAndMessage = this.priorityQueue.Dequeue();

                }while(!clientAndMessage.ClientId.Equals(clientId) && priorityQueue.Count > 0);

                if (clientAndMessage.ClientId.Equals(clientId))
                {
                    message = clientAndMessage.Message;
                    return true;
                }
                return false;

            }
            return false;
        }
    }
}
