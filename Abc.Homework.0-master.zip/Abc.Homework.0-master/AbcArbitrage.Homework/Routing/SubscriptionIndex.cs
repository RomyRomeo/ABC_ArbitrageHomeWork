// Copyright (C) Abc Arbitrage Asset Management - All Rights Reserved
// Unauthorized copying of this file, via any medium is strictly prohibited
// Proprietary and confidential
// Written by Olivier Coanet <o.coanet@abc-arbitrage.com>, 2020-10-01

using System.Collections.Generic;
using System.Linq;

namespace AbcArbitrage.Homework.Routing
{
    public class SubscriptionIndex : ISubscriptionIndex
    {
        //ADDED
        public List<Subscription> _subscriptions;
        public SubscriptionIndex() { _subscriptions = new List<Subscription>(); }
        
        public void AddSubscriptions(IEnumerable<Subscription> subscriptions)
        {
            // TODO => DONE
            foreach (Subscription subscription in subscriptions)
            {
                this._subscriptions.Add(subscription);
            }

        }

        public void RemoveSubscriptions(IEnumerable<Subscription> subscriptions)
        {
            // TODO => DONE
            foreach(Subscription subscription in subscriptions)
            {
                this._subscriptions.Remove(subscription);
            }

        }

        public void RemoveSubscriptionsForConsumer(ClientId consumer)
        {
            // TODO => DONE
            _subscriptions.RemoveAll(s => s.ConsumerId.Equals(consumer));
        }

        public IEnumerable<Subscription> FindSubscriptions(MessageTypeId messageTypeId, MessageRoutingContent routingContent)
        {
            //TODO => DONE

            var s = this._subscriptions;

            foreach (var subscription in this._subscriptions)
            {
                if (subscription.MessageTypeId.ToString() == messageTypeId.ToString())
                {
                    if (subscription.ContentPattern.Parts.Count == 0 && routingContent.Parts == null)
                    {
                        yield return subscription;
                    }
                    else if (subscription.ContentPattern.Parts.Count != 0)
                    {
                        if (routingContent.Parts == null)
                        {
                            yield break;
                        }

                        bool contain = subscription.ContentPattern.Parts.Any(p => routingContent.Parts.Contains(p));
                        if (contain) yield return subscription;

                    }
                }       
                    
            }

            yield break;
        }
    }
}
