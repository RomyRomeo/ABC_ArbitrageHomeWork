# Routing exercise Answers



Complete this document with your answers.



----

### Candidate Name: Romeo TAKOUDJOU TAKOU


### Date: July 16th, 2024

-----



## A. Implement SubscriptionIndex

- A1 : Since I didn't understand subscription with pattern concept, the  tests about it failed.
       I am still trying to understand.

- A2.  Write the names of the tests you added here: No more tests added
 

- A3.  Briefly document your approach here (max: 500 words)
  


## C. Improve SubscriptionIndex performances (Bonus)

- C1. 
  - Did you find a solution where the benchmark executes in less that 10 microseconds? : No
    
  - If you did, briefly explain your approach (max: 500 words): 
    



------

### Candidate survey (optional)

The questions below are here to help us improve this homework.

1. How did you find this homework? (Easy, Intermediate, Hard)
    Intermediate

2. How much time did you spend on each questions?
   - A : 2h
   - B : 1h
   - C : 1h

   
